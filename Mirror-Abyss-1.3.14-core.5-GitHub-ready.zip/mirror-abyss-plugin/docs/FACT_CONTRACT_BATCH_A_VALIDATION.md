# 批次 A：事实身份与归属验证记录

版本：Mirror Abyss `1.3.14-core.4`  
流水线：`ma-pipeline-81`  
日期：2026-07-23

## 1. 修改边界

本轮只落地《镜渊统一记忆契约 V0.1》的批次 A，不改审核、修订、请求调度、任务队列、聊天提交守卫、总结生成协议、UI 和 SillyTavern 正文生成。

新增统一事实门 `domain/fact-contract.js`，并接入：

- 自然事实模块解析；
- 事实包规范化；
- 聊天级内部事实规范化与合并；
- 状态业务形状校验；
- 事件总结分组；
- 事件画像；
- 世界书事实回退；
- ChatState 旧数据迁移。

## 2. 已实现契约

每条内部事实现在至少具有：

- `factId`
- 可选 `eventId`
- `subjectRef`
- 唯一 `primaryHost`
- `facet`
- `storageClass`
- `validFrom` / `validTo`
- `supersedesFactId` / `supersededByFactId`
- `evidenceKind`
- `projectionHint`
- 来源消息与总结消费标记

保存层级固定为：

- `working`
- `episodic`
- `event`
- `durable`

旧事实若有确定投影，按既有稳定行 ID 补齐宿主；没有确定投影时进入 `legacy:<factId>`，不会根据标题或关联对象猜测宿主。

## 3. 准入与隔离

- `eventId` 不再由内部规范化器自动生成。
- 类型为事件的事实仍必须具有 `eventId`。
- 新角色只有外观切面时：
  - 事实保留；
  - 主宿主改为 `episodic`；
  - 保留弱对象引用；
  - 禁止可见角色投影。
- 已有稳定角色的当前外观可以正常更新。
- `episodic` 默认不进入：
  - 下一轮状态模型上下文；
  - 小总结事件分组；
  - 事件画像；
  - 世界书正式发布。

## 4. 当前值与变化史

替换型对象切面的本地规则：

- 内容未变化：复用当前 `factId`；
- 内容明确变化：生成新 `factId`；
- 新事实写入 `supersedesFactId`；
- 合并时旧事实写入 `validTo`、`supersededByFactId` 并退出当前态；
- 新旧事实、稳定对象 ID 和来源消息均保留。

追加型事实继续沿用原累计逻辑，没有被统一拆成碎片。

## 5. 迁移

ChatState schema 从 3 升级到 4，新增一次性迁移标记：

```text
factContractV35
```

迁移只补齐可推导的契约元数据，不改旧 `factId`、`eventId`、事实正文、总结消费标记或稳定对象 ID。

## 6. 离线验证

执行：

```text
npm run verify:core
find . -name '*.js' -not -path './node_modules/*' -print0 | xargs -0 -n1 node --check
```

结果：

- Node 回归：29/29 通过；
- JavaScript 语法检查：通过；
- 版本标识一致：`constants.js`、`manifest.json`、`package.json` 均为 `1.3.14-core.4`；
- 流水线标识：`ma-pipeline-81`。

新增验证覆盖：

1. 无事件情景事实不会伪造 `eventId`；
2. 背景侍卫只有红衣外观时不创建角色卡；
3. 已建档角色外观仍可更新；
4. `episodic` 不进入事件总结、画像或世界书；
5. 显式替换链关闭旧有效区间；
6. 自然模块的未变化值复用事实、变化值创建新事实；
7. 旧事实补齐契约字段但不猜测对象宿主。

## 7. 尚需实机与后续批次

- 未执行真实 SillyTavern schema 3 → 4 升级保存与重载。
- 未执行真实世界书写入、回读和向量召回。
- 情景事实目前完成“保存与默认隔离”，尚无对象＋切面＋时间范围查询索引。
- 当前自然文本协议仍以 `<MA_EVENT>` 组织候选事实；普通单回合候选事件的进一步本地降级尚未完成。
- 事实账本尚不能纯本地重建全部动态表格。
- 生命周期仍未逐 `factId` 验收承接。

因此本版仍是测试候选版，不应冒充已完成 SillyTavern 实机稳定验证。
