# Mirror Abyss 上传 GitHub 说明

本压缩包包含两部分：

- `mirror-abyss-plugin/`：GitHub 仓库源码。上传时应把这个目录中的内容放到仓库根目录。
- `release-assets/Mirror-Abyss-1.3.14-core.5.zip`：SillyTavern 安装包。适合作为 GitHub Release 附件上传，不建议提交到源码目录。

## 已有仓库的推荐方式

1. 在电脑上克隆或打开 `228184520lyd-boop/mirror-abyss-plugin`。
2. 将 `mirror-abyss-plugin/` 内全部文件复制到本地仓库根目录并覆盖同名文件。
3. 提交并推送：

```bash
git add -A
git commit -m "Release 1.3.14-core.5"
git push
```

4. 在 GitHub 仓库的 Releases 页面创建 `1.3.14-core.5`，上传 `release-assets/Mirror-Abyss-1.3.14-core.5.zip`。

## 注意

不要把最外层的 `Mirror-Abyss-1.3.14-core.5-GitHub-ready.zip` 直接作为源码提交；GitHub 不会自动把它解压成可浏览的仓库文件。
