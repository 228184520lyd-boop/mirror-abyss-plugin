# 1.1.0-rc.2 — Memory evidence and recall contract candidate

- 新增小总结事件证据边界：`event_entry` 与 `long_term_candidate` 必须引用本批真实 `source_fact_ids` 或变化行 `source_row_ids`；缺失、伪造、旧来源或上下文锚点 ID 进入纯文本协议修正，不提交到事件注册表。
- 协议修正仍失败时保留既有事实、活跃表格、小/大总结、事件、世界书和剩余小总结批次，只把真实协议错误交给现有恢复路径。
- 旧事件缺少来源时只标记为“旧数据未校验”，不删除、不重写；新事件执行严格来源契约。
- 新增最多 1,600 字符的常驻场景锚点，仅包含当前焦点和最近两条时空状态，不发送完整表格，并声明不得替玩家决定心理、目标或行动。
- 分层记忆界面新增证据数量、实际有效触发方式、服务器回读状态和“宿主未提供逐轮命中回执”提示；向量不可用时显示关键词降级，不把发布成功等同于正文已注入。
- 保持 `ma-pipeline-10.7.4`、RC.1 队列排空、504 拆分、调度槽位、同聊天串行、AbortSignal、Outbox、聊天作用域和旧数据迁移语义不变。
- GitHub `main` 仍落后于本地基线，因此候选部署包关闭 manifest 自动更新，防止安装后意外回退到旧代码。
- 本地独立分支 `product/memory-contract-v1-rc.2`；未上传服务器、未合并 main。

# 1.1.0-rc.1 — Simulated-player stability candidate

- 修复普通游玩触发小总结时只处理首个预算批次、随后提前进入大总结的问题；现在会先排空本次规划的全部小总结批次。
- 修复检查点恢复时把刷新后新增事实追加进旧批次队列的问题；续跑严格限定为已持久化 source IDs。
- 新增长局、预算边界、无变化、504 拆分、刷新续跑、检查点阶段、本地事务、重复抑制、取消和 stale 作用域的模拟玩家回归测试。
- 以 `1.1.0-alpha.10.7.15` 上传包为基线；保持 `ma-pipeline-10.7.4` 和现有调度、流式降级、Outbox、聊天隔离契约不变。
- 未合并 main，未上传服务器；真实云端 SillyTavern 验收通过前保留 RC 标记。

# 1.1.0-alpha.10.7.15 — Small-summary rebuild batching and adaptive 504 recovery

- 将小总结历史重建从“全部未消费材料一次请求”改为完整事实单元的顺序分批；集中限制为完整请求预算最多 12,000 字符、变化事实最多 24 条。
- 预算计算包含系统提示词、标签协议、轮次材料、事实、变化行、直接操作、上下文锚、匹配事件和协议重试余量；取消提示词内部静默截断，单个结构化事实超限时在调用模型前明确失败。
- 小总结运输层固定单次尝试。HTTP 504、gateway/upstream timeout、未获得首数据的已知上游时间边界和无内容流断开优先按完整事实边界自适应二分，不原样重试超大请求。
- 普通网络瞬断最多允许一次同批重试；拆分父批次只保留诊断，不进入小总结、大总结输入、事件注册表、世界书或 Outbox。
- 稳定批次键绑定 chatKey、history revision、rebuild generation、summary type 和有序 source IDs；每个成功/无变化批次立即原子提交并记录幂等账本。
- 历史检查点细化为待处理批次、已完成批次键、已生成小总结 ID、剩余 source IDs/消息键/事实包、当前批次、拆分树和下一 source；刷新、取消或失败后只续跑首个未完成批次。
- 任务与恢复界面新增实际输入、预算占用、事实数、attempt、当前/总批次、source 范围、自适应拆分、同输入重试和 HTTP 状态；未获得首数据时显示 N/A。
- 保留 `ma-pipeline-10.7.4`、现有调度并发、聊天隔离、AbortSignal、事实顺序、表格、小/大总结、世界书协议、Outbox 与 `.10.7.14` 本地提交恢复逻辑。

# 1.1.0-alpha.10.7.14 — Small-summary local-commit recovery

- 将小总结本地提交阶段纳入失败注解，提交冲突继续保留原始错误、精确 `failedSummarySourceKeys`、`smallSummaryInputCounts` 与 `smallSummaryFailureKind`。
- 续跑时在模型调用前检查相同 intent 的 `prepared`、`committing` 和 `committed` 本地事务；可安全恢复时直接提交并取回对应 sourceKeys 的小总结，不重复请求模型。
- 修复 `chatState.historyRebuild` 在失败落盘后变化导致待恢复事务被误判冲突：仅当去除该恢复字段后的业务状态仍与事务前态或后态精确一致时，合并最新恢复元数据并重算事务指纹。
- `conflict`、`cancelled` 或 sourceKeys 不匹配的事务不会覆盖当前聊天状态；缺少精确结果时失败关闭并保留恢复记录。
- 保持既有事实包、表格、有效总结、大总结、世界书 Outbox、聊天隔离、scope revision、AbortSignal 与旧数据兼容。
- 保持 `ma-pipeline-10.7.4`、API 优先级调度、流式降级白名单、每 Profile 两槽、派生任务一槽及同聊天串行不变。

# 1.1.0-alpha.10.7.13 — Small-summary semantic boundary and derived recovery

- 用代码根据事实包、表格操作与前后快照生成 `changedRows`、`affectedRows` 和最小 `contextAnchors`，小总结不再接收完整当前活跃表格。
- 语义指纹忽略 `updatedAt`、普通存储字段、无意义顺序及内部字段，保留内容、状态、生命周期、关系端点、手工/锁定状态等业务变化。
- 历史重建使用事实包对应的阶段快照，阻止早期小总结观察后续物品、技能、人物或事件状态。
- 无变化批次以内部幂等记录标记为已消费，不调用模型、不生成空小总结、事件或长期候选。
- 小总结失败时保留已重建事实与表格检查点，记录失败 `sourceKeys` 并只重试该派生批次；不重做成功的正文事实提取。
- 任务卡和诊断显示小总结错误分类、输入边界数量和对应检查点，不记录完整提示词或响应。
- 保持 `ma-pipeline-10.7.4`、API 优先级调度、流式白名单、每 Profile 两槽、派生任务一槽、同聊天串行及现有业务协议不变。

# 1.1.0-alpha.10.7.12 — Resumable history rebuild failures

- 将历史重建失败明确划分为连接预检、缓存事实重放、缺失正文事实提取、小总结重建、大总结重建和最终世界书同步六个阶段。
- 事实批次从持久化的失败起点继续；已完成批次和已成功事实包保持不变并通过缓存重放恢复现场。
- 小总结、大总结和最终同步各自保存阶段检查点；大总结失败不重跑小总结，最终同步失败不重跑模型任务。
- 连接预检失败统一进入非破坏式等待，保留现有数据、检查点、有效总结、Outbox 与恢复标记。
- 解包被 `PipelineStageError` 包装的真实模型错误，并在任务卡、恢复页和诊断中显示阶段、批次、`errorKind`、HTTP 状态、连接与最近模型 timing。
- 新增阶段映射、事实批次检查点、连接恢复、大总结跳过小总结及错误透传回归测试。
- 保持 `ma-pipeline-10.7.4`、API 优先级调度、每 Profile 两槽、派生任务一槽、同聊天串行和现有事实/总结/世界书协议不变。

# 1.1.0-alpha.10.7.11 — Strict stream fallback whitelist

- 将流式兼容性识别由宽泛关键词改为错误类型、明确错误代码和受限文本白名单，`upstream` 不再因包含 `stream` 子串而误判。
- Connection Profile 未返回生成器工厂、工厂未返回 AsyncGenerator、对象缺少 `Symbol.asyncIterator`，或明确表示流式接口不支持/未实现/缺失时，最多降级一次。
- HTTP、上游连接、网络、API、模型、HTML、JSON/SSE 解析、取消、stale 以及收到首段数据后的错误不降级。
- 新增回归测试，验证不会出现第二次误调用或降级失败后的第三次调用；保留累计 `text` 的最新值聚合。
- 当前恢复包无法可靠重建与运行代码一致的 `index.js.map`，发布归档明确排除该旧映射。
- 保持 `ma-pipeline-10.7.4`、优先级策略、每 Profile 两槽、派生任务一槽、同聊天串行及业务协议不变。

# 1.1.0-alpha.10.7.10 — API wait latency and timing diagnostics

- 每次模型调用记录 TaskQueue、请求槽、首数据、完整响应、解析、本地提交与聊天保存耗时；任务中心与诊断导出均可查看，且不保存提示词、响应或密钥。
- Connection Profile 严格 FIFO 改为集中配置的优先级调度：每 Profile 最多 2 个请求，派生总结最多占 1 个槽，同一聊天仍保持单请求顺序。
- `audit/revision`、`factExtraction/state`、`smallSummary`、`largeSummary` 依次降级；尚未发送的大总结允许关键事实任务越过。
- 事实提取完成本地提交后立即释放关键任务 lane，小总结、大总结与世界书改由独立派生任务继续。
- Profile 请求启用完整流式聚合，收到完整文本后才解析；兼容性失败仅允许一次非流式降级。
- 不抢占正在生成的大总结；新事实会显示准确的 Profile 等待耗时，并在当前请求释放后优先执行。
- 保持 `ma-pipeline-10.7.4`，不重新处理已成功正文。

# 1.1.0-alpha.10.7.8

- 历史重建默认改为手动：进入或切换聊天只做本地一致性检测，不调用模型 API。
- 编辑、删除或 Swipe 旧正文时，默认只建立非破坏性的“历史变化待处理”记录。
- 检测到变化后保留现有表格、事件总结和大总结；正文审核仍可继续，新的记忆派生等待玩家手动重建。
- 新增“自动历史重建”可选开关，默认关闭。
- 恢复页与诊断页显示明确的手动开始入口，不再把待处理状态显示为正在重建。

# 1.1.0-alpha.10.7.8 — Adaptive fact extraction

- 将事实提取字符预算从约 52,000 降至约 18,000。
- 单轮 429/502/503/504、网络异常和协议缺失采用指数退避有限重试。
- 多轮批次失败时自动二分拆批，再按顺序更新表格。
- 历史重建批次改为默认 6 条、范围 4–10 条。
- 为旧表格、阶段事实、事件注册表、上一版长期记录和长期候选分别设置总量预算；优先保留焦点、基础设定、手工锁定、当前活跃及正文提及对象。
- 小总结和大总结增加瞬时错误退避及一次协议纠错重试。
- 保留非瞬时 HTML 配置错误不重试，避免反复请求错误网页端点。
- 保持 `ma-pipeline-10.7.4`，不重复处理已成功正文。

# 1.1.0-alpha.10.7.6 — Model routing and profile diagnostics

- 固定两种模型来源：当前正文连接、指定 Connection Profile。
- Named Profile 始终通过 `ConnectionManagerRequestService.sendRequest(profileId, ...)` 直调，不切换全局连接。
- 新增 Profile 路由指纹；任务排队后 Profile 被修改时安全停止。
- 将全局 Profile 串行锁改为按 Profile 分离的请求通道。
- 新增当前连接与指定 Profile 的双通道对照诊断。
- Profile 失败时禁止静默回退到其他模型。
- 保持 `ma-pipeline-10.7.4`，不重新处理已成功正文。

# 1.1.0-alpha.10.7.5 — History dependency recovery

- 在失效历史真正删除前执行 `factExtraction` 连接预检；返回 HTML 时进入非破坏式等待状态。
- 预检成功后才提交历史失效事务，并在全部原文回读批次中固定使用同一 Connection Profile 快照。
- 历史依赖失败不再阻止正文审核和准入，仅暂停表格、事件总结、大总结及世界书发布。
- 重建完成后自动补排等待中的审核后正文。
- 记录并显示重建错误类型、HTTP 状态和实际连接名称。
- 保持 `ma-pipeline-10.7.4`，不重复处理已经成功的正文。

# 1.1.0-alpha.10.7.4.2

- 修复 ES Module 解析阶段的顶层重复函数声明 `intersects()`。
- 该冲突会导致扩展脚本在执行任何启动代码之前直接加载失败，因此图标、设置面板和启动失败提示均不会出现。
- 将事件连续性辅助函数改名为 `eventListsIntersect()`，保留历史总结一致性模块原函数。
- 保持 `ma-pipeline-10.7.4` 不变，不触发正文重新提取。

# Changelog

## 1.1.0-alpha.10.7.4.2

- 修复启动被世界书服务器回读阻塞：先挂载设置面板、入口图标和事件监听，再后台回读。
- 世界书连接慢、代理异常或读取悬挂时，插件仍能正常启动，错误仅进入回读状态。
- 聊天切换后先刷新焦点卡、正文状态条和工作区，再异步校验世界书。
- 保持 `ma-pipeline-10.7.4` 不变，避免热修复导致已处理正文被重复提取。

## 1.1.0-alpha.10.7.4

- Added independent server readback verification with actual lorebook fingerprint, managed entry count and verification timestamp.
- Revalidates the latest committed lorebook after startup, chat switches, window resume and explicit UI checks.
- Message panels now merge live task-queue state so queued/running feedback is immediate.
- Added automatic idempotency guard for already-approved正文 with a successful fact table.
- Added conservative event-ID continuity recovery for one uniquely matching old event.
- Added explicit vector capability detection and keyword fallback when vector retrieval is known to be unavailable.
- Added diagnostics for lorebook drift and duplicate event identities.

## 1.1.0-alpha.10.7.3

- 为诊断失败/警告状态增加对应恢复按钮，不再只显示错误。
- 为任务中心的审核、修正、事实提取、总结和世界书失败任务增加阶段级重试。
- 正文下方按钮点击后立即显示忙碌状态，并统一捕获、显示重试结果。
- 正文状态条订阅流水线与任务队列，并在窗口恢复焦点时回读，减少旧状态。
- 新增正文状态条数量、渲染积压、控制台渲染循环和重试覆盖诊断。
- 统一按钮、卡片、状态徽标、焦点样式和移动端布局，不改变原有导航结构。


## 1.1.0-alpha.10.7.2

- 串行化底层 Connection Profile 传输，任务与 UI 仍保持异步，避免不同 Profile 首次调用串线。
- 连接测试冻结所选 Profile 快照，错误标题与实际调用连接保持一致。
- 世界书事务状态写入后主动回读状态并触发 UI 刷新；渲染期间的新刷新请求不再丢失。
- 恢复独立“焦点卡”：当前焦点被模型误分类为 character 时，投影层会确定性归位并清理自动重复人物行。
- 启动与切换聊天时修复最新快照中的旧焦点分类，无需额外 API 调用。
# Changelog

## 1.1.0-alpha.10.7.1 — Upstream HTML Diagnostics

- 修复 `factExtraction` 上游返回 HTML 页面时，UI 同时显示外层诊断与底层 `Unexpected token '<'` JSON 解析异常的问题。
- 错误信息现在标明当前聊天连接或具体 Connection Profile，并安全显示 API 类型、模型名、HTTP 状态和页面标题。
- 按 401/403、404、429、502/503/504、登录页和网关页提供针对性的端点、代理、鉴权或服务状态提示。
- 明确将该故障分类为 `upstream_html`，避免误判为事实提取协议、事件 JSON 或提示词格式错误。
- 非瞬时 HTML 配置错误不再触发历史重建批次自动重试；502/503/504 仍允许按瞬时网关故障重试。
- 正文准入、事件记忆、世界书事务、关系图谱和现有异步 UI 流程保持不变。

## 1.1.0-alpha.10.7.0 — Event Memory, Propagation & Sedimentation

- 将整块小总结降为玩家可见的阶段概览；新增独立事件条目作为实际记忆、更新和世界书发布单元。
- 事件条目记录稳定 ID、事实、参与者、地点、发生时间、最后确认时间、状态、传播范围、已知者、渠道、误传、痕迹、影响、精度、重要度和来源。
- 新增 `exact → compressed → fuzzy → trace` 精度序列；没有新事实确认时禁止提高精度。
- 新增条目级 `constant / keyword / vector` 发布方式；限制常驻滥用，并强制模糊与痕迹信息使用向量方式。
- 小总结读取既有事件注册表以复用稳定事件 ID、延续传播和比较精度，但仍只从事实包与活跃表格生成新内容。
- 大总结协议新增 `event_update`，可保持、沉降或在严格条件下删除本批事件；大总结仍不读取正文和当前表格。
- 事件注册表改为由所有有效小总结操作与大总结沉降操作确定性重建，支持编辑、删除、Swipe 和历史重建后的依赖失效。
- 世界书不再发布整块小总结；每个事件条目按自己的注入方式独立发布。
- 前端“分层总结”升级为“分层记忆”，显示事件状态、精度、传播范围和注入方式分布。
- 关系图谱继续保持只读，不参与正文、表格、事件或总结。

## 1.1.0-alpha.10.6.0 — Admission Gate & Strict Memory Lineage

- 固定数据链为“最终正文 → 正文准入 → 活跃表格 → 小总结 → 大总结 → 世界书”。
- 新增正文准入元数据和硬校验；审核关闭时零审核请求并显式 bypass，审核通过或修正后才允许事实提取。
- 表格事实模型调用前后均核对聊天、正文指纹和准入指纹，阻止候选正文或过期结果污染记忆。
- 历史重建不再在事实提取调用中同时生成阶段总结。
- 缓存重放不再本地拼接小总结；需要重建的阶段记忆重新走异步小总结模型。
- 强制小总结仍遵守轮数阈值，长历史按多批生成，避免单次提示词无限扩大。
- 大总结移除当前活跃表格输入，只继承上一版长期记录、小总结及其长期候选。
- 大总结提示词增加精度继承限制，禁止恢复已经沉降模糊的旧细节。
- 前端任务名称和总览说明改为真实数据链；关系图谱明确为只读观察层。
- 本次基于部署包直接恢复开发，执行部署产物级静态与语法验证；原 TypeScript 自动测试需在后续恢复源码工程后补跑。

## 1.1.0-alpha.10.5.5 — Plain-Text Native Protocol

- 统一事实提取、状态表、小总结和大总结取消模型端 JSON Schema 与强制 JSON 输出，统一改为 `<ma_facts>`、`<ma_state>`、`<small_summary>`、`<large_summary>` 纯文本标签协议。
- 删除运行时 JSON 格式修复模型和对应设置；结构无法解析时直接显示任务失败，不追加第二次模型调用。
- 当前连接调用不再向 `generateRaw` 传入 `jsonSchema`；Connection Profile 继续使用 SillyTavern 原生请求服务。
- 输入侧也取消整块 JSON 序列化：活跃表格、事实素材和长期记录改为紧凑自然文本区段，降低 Token 与生成负担。
- 上游返回 HTML 错误页或抛出 `Unexpected token '<' ... not valid JSON` 时，直接报告“上游返回HTML错误页”，不再误报为事实包 JSON 解析失败。
- 保留旧 JSON 模型返回的只读兼容解析，便于旧测试、旧代理和过渡存档，但新提示词不会要求 JSON，也不会执行 JSON 修复。
- 连接测试改为固定文本 `MA_CONNECTION_OK`，UI 显示“文本协议有效/无效”。
- 30/100 轮与 120 条历史重建调用次数不变；纯文本端到端、HTML 错误、无 Schema 请求和旧返回兼容测试通过。
- 修复测试聚合器在带 ANSI 颜色输出时误统计为 0/0；洁净源码现在稳定汇总为 103/103。

## 1.1.0-alpha.10.5.4 — Cache-First Rebuild & Task UI

- 历史重建改为缓存优先：稳定统一事实包、表格检查点和有效总结先本地复用，只有缺失或失效区段才回读正文。
- 连续缓存包批量重放并一次持久化，避免长存档逐条写 IndexedDB/聊天元数据；模型调用为 0。
- 完整缓存手动重建跳过大总结调用；仅在正文回读或总结依赖失效时更新长期脉络。
- 事实包按稳定消息键重映射当前来源索引，兼容历史删除、插入和下标变化。
- 有效小总结保留；混合总结失效时使用既有逐轮摘要恢复阶段记忆，不重新发送未变化正文。
- 重建任务增加 planning、复用缓存、回读缺失、更新长期、同步世界书阶段，并记录复用/回读/缓存包/模型批次数。
- 任务中心 UI 增强状态图标、渐变任务卡、进度条、错误区、重建指标和移动端两列信息布局；现有工作台导航与业务功能不变。
- 新增缓存优先局部编辑、完整缓存零调用和任务 UI 回归；自动测试 100/100，完整构建链通过。

## 1.1.0-alpha.10.5.3 — Native Invocation & Rebuild Task Feedback

- 所有模型请求收缩为 SillyTavern 原生调用：当前连接使用 `generateRaw`，指定 Connection Profile 使用 `ConnectionManagerRequestService.sendRequest`。
- 删除运行时自建模型 fetch、独立 API 配置、Connection Broker、Invocation Router、网络重试、超时、限流与熔断；镜渊仅保留提示词、业务任务、检查点和结果落盘。
- 历史重建改为非阻塞后台父任务，入口立即返回；批次进度、消息范围、耗时、重试、成功与失败持续显示在顶部入口和任务中心。
- 历史批次在一次原生模型调用中同时形成统一事实、活跃表格更新、阶段小总结与沉降凭证；全部批次结束后只更新一次大总结。
- 成功批次原子更新表格和重建检查点；失败不覆盖已成功表格，可从失败批次继续；中间世界书发布继续暂停，末尾只发布最终版本。
- 修复 `stageSummary` 归一化后未返回，导致批次小总结实际丢失；修复最终大总结开始前未持久化 running 阶段造成的本地提交冲突。
- 顶部按钮显示任务运行/失败徽标；任务中心保留错误全文与重试入口，同一任务重跑成功后旧失败告警不再持续。
- 新增原生历史重建与任务反馈端到端测试；自动测试 97/97，生产构建与边界检查通过。

## 1.1.0-alpha.10.5.2 — Frozen Performance Patch / No Feature Expansion

- 调用路由与连接代理统一使用脱敏凭据级通道；多个配置共用同一端点与密钥时不再并发压测同一上游。
- Connection Broker 增加优先级队列：前台审核可越过尚未开始的后台事实、总结与 I/O，请求执行中不抢占。
- 事实提示词裁剪内部更新时间与冗余标志，手工/锁定行统一为 `protected=true`，关系端点与生命周期继续完整保留。
- 统一事实调度增加 52,000 字符预算；短轮突发保持单批，超长正文和历史重建按体积拆批，全部正文仍按顺序处理。
- 同一次总结周期复用消息键→事实包索引，消除大总结来源范围计算中的重复全聊天扫描。
- 批量事实派生只再次保存区段末条；旧延迟派生任务被后续区段替代时明确结束为 skipped。
- 30/100 轮调用结构保持 69/230 次；108 行表格合成样本的事实提示词由 57,577 bytes 降为 39,106 bytes（32.1%）。
- 新增 4 项性能回归测试；37 个测试文件全部通过，模型调用语义与五项现有功能保持不变。

## 1.1.0-alpha.10.5.1 — Detection Bugfix / Existing-Function Reliability

- 修复批量沉降时所有时间地点锚点可被同时删除；增加显式剩余计数与回归测试。
- 统一事实 v3 以 `facts` 为唯一语义来源，忽略模型额外输出的冲突表格操作；无事实的旧协议仍兼容。
- 已有稳定对象在模型漏写标题时复用旧行标题，修复部分“事实已提取但表格没有更新”的情况。
- 世界书关键词允许单字母、单数字和单字中日韩对象名，避免非常驻条目因空关键词永不触发。
- 焦点去重的 mergedRowIds 按身份分组，不再把其他焦点的重复行错误归入当前焦点。
- 世界书待发布任务被更新版本替代时，旧任务明确标记为已合并。
- 已有镜渊状态的聊天在返回时检测未处理正文尾部并批量恢复；未初始化旧聊天不自动回扫。
- 新增 8 项回归断言与 200 例定向压力检查；自动测试 102/102。模型调用结构不变。

## 1.1.0-alpha.10.5 — Memory Transfer Integrity / Phase 4 Existing-Function Closure

- 小总结增加精确吸收凭证 `absorbedRowIds` 与 `keepActiveRowIds`；同一次阶段总结调用同时完成压缩、活跃判定和沉降授权。
- 沉降优先使用稳定行 ID 验证，不再依赖标题或关键词碰巧出现在总结文字中；旧总结保留文字匹配兼容。
- 小总结增加结构化长期候选，死亡、永久损毁、永久失去、不可逆关系变化等可直接进入长期脉络。
- 大总结改为对象记录操作：模型仅输出 `upsert / remove / merge`，代码确定性维护长期记录并渲染最终大总结。
- 未变化旧记录自动保留；被模型漏写的长期候选自动补入；不可逆记录拒绝裸删除。
- 旧模型返回完整 summary 的行为继续兼容，不触发额外语义调用。
- 世界书激活规则集中为固定映射：基础设定常驻，其余条目关键词触发；开启现有向量开关时非常驻条目同步向量化。
- 小总结输入去除无关事实元数据，大总结只读取对象记录、长期候选和当前表格锚点，降低阶段调用输入体积。
- 30 轮与 100 轮调用结构保持 alpha.10.4 水平；新增吸收凭证、长期对象操作、不可逆保护和激活映射回归，自动测试 94/94。

## 1.1.0-alpha.10.4 — Memory Completion / Phase 3 Existing-Function Reliability

- 恢复模型生成的小总结：只读取统一事实包和当前活跃表格，不再重新发送原始正文；输出阶段压缩与最终沉降计划。
- 恢复模型维护的累计大总结：读取上一版大总结、新小总结和当前活跃表格，执行修改、删除、合并与长期压缩，不再使用本地行追加。
- 扩大安全沉降到 relationships、items、skills；只有已经结束或不再活跃、非手工、非锁定且结果已被小总结吸收的行才能退出表格和世界书。
- 死亡、永久失去、关系断裂、物件销毁等既定结果必须先写入小总结；人物正式记录继续由生命周期管理，沉降器不直接删除。
- 沉降增加“总结吸收校验”：小总结未提及对应对象时，即使模型请求删除也会被代码拒绝并记录 ignoredRowIds。
- 关系事实新增可选 sourceEntityId/targetEntityId；新图谱优先按稳定 ID 连线，旧存档继续使用名称匹配回退。
- 统一事实提示词要求 relationship 明确返回双方稳定对象 ID；关系端点随表格增量、快照、世界书和聊天数据持久保存。
- 模型连接收敛为两个实际角色：审核与修正共享前台连接；事实、表格、小总结和大总结共享后台记忆连接。
- 保留快速积压合并：10 轮突发仍只做 1 次事实提取；阶段与长期总结各按阈值调用，不重复理解正文。
- 30 轮完整模拟为审核 30、事实 30、小总结 6、大总结 3；违规轮次仍无独立修正或复审调用。
- 新增沉降吸收保护、关系/物件/技能退出、死亡事实保留、稳定图谱端点与模型总结回归；自动测试 91/91。

## 1.1.0-alpha.10.3 — Deterministic Memory / Phase 2 Data Semantics

- 统一事实包升级为 v2：模型只输出事实、逐轮摘要、焦点身份和沉降候选，不再要求完整九表 `finalSnapshot`。
- 新增事实到九类表格的代码映射与增量投影；未变化的当前活跃行保持不动，历史与旧痕只进入总结素材。
- 保留 alpha.10.2 旧事实包兼容：缺少行标题时继续使用旧 `finalSnapshot` 回退。
- 新增聊天级焦点身份注册表，按 focusId、别名、行 ID 和标准化名称合并重复卡；切换焦点时只保留一个当前标记。
- 焦点注册表进入可移植 ChatState，刷新或本地缓存丢失后可从聊天元数据恢复。
- 世界书常驻语义收紧：仅基础设定允许常驻，时间地点、焦点、人物、事件、区域、物件和总结均改为关键词触发。
- 世界书发布和图谱显示会过滤标准化同名的重复焦点卡；下一次发布自动迁移旧托管条目的 constant 标记。
- 新增确定性事实分发、旧包回退、焦点别名复用与切换、常驻分类、便携恢复和输出体积回归。
- 恢复逐测试文件的隔离运行与强制退出，避免洁净发布验证因测试句柄残留而挂起。

## 1.1.0-alpha.10.2 — Runtime Backpressure / Phase 1 Stability

- 以仓库 alpha.9.7 为基线，将正文审核保留为前台闸门，统一事实、状态、总结、沉降、图谱和世界书调整为后台任务。
- Invocation Router 按“聊天＋捕获的连接身份”分通道；同连接保持顺序，不同连接可并行，前台任务可越过尚未运行的后台任务。
- 新增统一事实批次调度：1 轮正常、2–4 轮合并、5 轮以上立即批处理并延迟低优先级派生，追平后只提交最新总结与世界书。
- 保留模型漏写的既有活跃状态行；自动退出必须经过小总结沉降，修复更新后表格不记录或静默消失。
- 新增最新世界书发布调度器，快速连续游玩只保留最新待发布版本；世界书失败不阻断正文。
- 手动重新发布即使内容未变化，也强制刷新 SillyTavern 世界书缓存、列表和编辑器。
- 历史重建改为 10–20 条一批、持久检查点、失败批次重试、刷新后续建、暂停/取消/恢复，并只在末尾发布最终世界书。
- 任务记录补充优先级、来源消息范围、进度与是否阻塞；长任务按钮统一禁用、显示执行状态并恢复。
- 新增不同连接并发、快速事实合并、世界书强制刷新、历史批次检查点、504 单批重试和表格连续性回归；自动测试 82/82。
- 30 轮快速完整模拟中审核 30 次、事实 30 次、世界书服务器写入 1 次；10 轮突发推进合并为 1 次事实调用。

## 1.1.0-alpha.9.7 — Summary Consistency / Phase 5 Candidate

- Added a deterministic per-file Node test runner that exits after all file summaries, preventing open test handles from stalling release validation.

- 将消息稳定身份与内容 revision 指纹分离；编辑、swipe、继续生成时保留逻辑消息身份但更新 revision key。
- 根据消息 revision → 小总结 → 大总结依赖链递归废弃旧派生数据，修复撤回/修正正文后错误事实继续污染长期记忆的问题。
- 删除消息、删除 swipe、编辑、swipe、MESSAGE_UPDATED 与分支差异统一进入历史重建通道。
- 新增持久 `HistoryRebuildRecord`，重建中断会进入 failed 并阻止后续总结/世界书写入；启动、切换聊天、诊断页和公开 recovery API 均可恢复。
- 历史重放按聊天取得跨标签租约，取消旧任务与连接；重放期间延迟世界书同步，只发布最后一个重建快照。
- 诊断页新增“总结依赖一致性”检查及“恢复总结依赖”入口。
- 新增编辑、删除、swipe、分支、重建中断/恢复、无变化更新过滤和 SillyTavern MESSAGE_UPDATED/MESSAGE_SWIPE_DELETED 事件回归；总计 72/72。
- 新增 `docs/PHASE5_ACCEPTANCE.md`，版本进入真实 SillyTavern 实机验收候选阶段，仍不标记 stable。

## 1.1.0-alpha.9.6 — Foundation Correction

- 以 SillyTavern 官方 `accountStorage` 和聊天元数据接口为账户/可移植状态边界，不新增猜测性的账户 API。
- TaskQueue 所有取消、过期、失败和成功路径统一 finalize；排队取消不再残留 `inFlight`，同一任务键可重新提交。
- 模型阶段失败改为抛出携带 artifact 的 `PipelineStageError`，队列、诊断和恢复器统一记录真实 `failed` 终态。
- 本地数据库按匿名账户实例 ID 分命名空间；缺少 `accountStorage` 时仅会话内降级，不再使用 origin-wide 持久回退。
- 聊天主键改为 `accountKey + persistent chatInstanceId`；角色排序、角色/聊天改名不改变主键，`CHAT_CREATED`/`GROUP_CHAT_CREATED` 明确轮换身份。
- ChatState 增加版本化聊天元数据副本，本地数据库缺失时可恢复总结、processed keys 和同步状态。
- 审核隔离锁记录控件精确原状态和所有权，只恢复镜渊自己取得的锁，不覆盖酒馆或其他扩展的禁用状态。
- 清理依赖反转：领域层移除宿主上下文，Repository 不再隐式读取当前聊天，LLM 不再反向依赖 Pipeline。
- 把 SillyTavern 世界书 HTTP、事件与编辑器刷新适配移入 `integrations/sillytavern-worldinfo.ts`，保留原 Outbox 事务。
- 加入 ESLint、依赖边界检查、发布契约测试；生产构建不再生成或分发 `index.js.map`。
- manifest 最低 SillyTavern 版本提升至 1.17.0，package/manifest/运行时版本统一为 1.1.0-alpha.9.6。
- 修正 Memory Books 上游仓库记录，不再声称无法复核的提交 SHA；外部插件仍只作为行为/架构参考。
- 新增任务终态、账户隔离、聊天身份事件、可移植状态、锁所有权、发布契约等回归；自动测试增至 68/68。

## 1.1.0-alpha.9.5 — Phase 4 Architecture Repair

- 补回源码包遗漏的 `tsconfig.json`，`npm run check` 现在可在发布源码中真实复现严格 TypeScript 检查。
- 重构扩展启用/禁用生命周期：禁用时取消启动计时器、任务与连接请求，卸载宿主事件、Router 订阅、消息面板、工作区、设置面板、顶部按钮、全局 API 与生成拦截器；重新启用只恢复一套监听器。
- 聊天主键不再使用可变 `characterId` 列表索引，改为稳定角色标识/群组标识与真实聊天 ID；读取聊天作用域不再隐式写入新聊天元数据。
- 增加 Phase 4 旧聊天键别名迁移：复制 ChatState、artifact、任务、Outbox、本地提交、日志与备份到稳定键，旧来源保留用于回滚。
- TaskQueue 从全局单 tail 改为按聊天 lane 排队；同聊天保持顺序，不同聊天可并行，连接层限流继续由 Connection Broker 负责。
- 正常管线把多阶段 artifact 更新合并为回合末一次完整聊天保存；LocalCommit 在最终聊天保存后确认消息附着，崩溃恢复路径仍可独立补齐。
- 设置模板增加真实内置降级版本，不依赖 `renderExtensionTemplateAsync` 也能挂载基本控制入口。
- 新增生命周期、稳定聊天身份、旧键迁移、按聊天任务 lane、保存合并和模板降级回归测试；自动测试增至 59/59。
- 100 回合状态提取模拟从 500 次完整聊天保存降为 100 次；30 回合审核＋状态＋总结＋世界书全链保持 30 次保存、全部 Outbox/LocalCommit committed。

## 1.1.0-alpha.9.4 — Foundation Kernel Phase 4

- 复核 Phase 3 并保留已通过的 Chat Scope、Connection Broker 和 Worldbook Outbox；新增复核报告 `docs/PHASE3_AUDIT.md`。
- 新增 CrossTabCoordinator：优先使用 Web Locks，同源不支持时降级为带 token、TTL、心跳和 fencing 的 localStorage 租约。
- Foundation Kernel 每次重新启动创建新的协调器实例，避免扩展删除/重载后复用已停止的 channel 与租约状态。
- 世界书提交按 `worldinfo:<bookName>` 取得跨标签独占协调，同时继续执行 Phase 3 的服务器基线指纹与回读校验。
- 小总结与大总结按 `summary:<chatKey>` 串行；artifact 与 ChatState 改为持久 LocalCommitRecord 双对象提交。
- 页面在 artifact/ChatState 两次写入之间退出时，启动或切回聊天可依据 before/after 指纹补齐；未知第三状态进入 conflict，不静默覆盖。
- 从用户提供的 alpha.6/alpha.7 部署 source map 提取真实旧数据库、键前缀、聊天键和消息 extra 结构，建立 preview → backup → conservative import 迁移链。
- 迁移按 `migration:<chatKey>` 取得跨标签锁；消息、元数据和 ChatState 均持久化并回读后才写入 migrationVersion 完成标记。
- 兼容 `mirrorAbyssV11` 旧 artifact、`mirrorAbyss.tableSnapshot` 更早快照、旧 ChatState、设置与聊天元数据；迁移不删除旧来源。
- 诊断页新增恢复包导出、已完成历史清理、世界书冲突取消/按最新状态重试、本地提交冲突取消。
- 操作日志改为 best-effort，日志配额或 IndexedDB 异常不会反向导致已完成事务失败。
- 重置流程保留未解决本地提交、Outbox 和迁移备份。
- 新增跨标签租约、本地崩溃恢复和旧版迁移测试；自动断言由 48 项增至 52 项。

## 1.1.0-alpha.9.3 — Foundation Kernel Phase 3

- 将世界书同步替换为持久 Outbox 事务：`prepared → committing → verify_pending → committed`，并记录回滚、冲突和取消状态。
- 所有世界书 GET/EDIT 请求贯穿任务 `AbortSignal`；写请求发出前取消即终止，发出后中断按未知结果回读恢复。
- 以捕获的聊天 `chatKey + scopeRevision` 约束整条发布链，修复读取与保存之间切换聊天导致的新聊天元数据污染。
- 使用每世界书锁和托管条目基线指纹进行乐观并发控制；检测到外部变化时拒绝覆盖。
- 服务器回读逐字段校验内容、关键词、常驻/向量设置、排序、托管集合、事务 ID 与 intent key。
- 同一已提交 intent 幂等重放，不重复调用世界书编辑接口，也不允许迟到旧快照覆盖较新状态。
- 写入成功但聊天元数据提交失败时，恢复实时元数据并条件回滚；回滚只恢复本聊天的镜渊托管条目，保留共享世界书中的无关条目。
- 页面启动和聊天切换后自动恢复未完成事务；已取消和冲突事务不会自动重放。
- alpha.7 旧托管条目按目标 key 选择性认领，补充聊天所有权和事务标记；未匹配旧条目不删除。
- 重置游戏若世界书结果未确认，会保留 Outbox 供恢复，不再把唯一恢复记录随缓存一起清除。
- 诊断报告增加 Outbox 状态、尝试次数、错误和冲突摘要；世界书页显示最近事务状态。
- 新增 10 个 Phase 3 故障注入场景；总自动断言测试由 37 项增至 48 项。

## 1.1.0-alpha.9.2 — Foundation Kernel Phase 2

- 保留 Phase 1 与全部既有镜渊领域/产品模块，在三种模型适配器上增加统一 Connection Broker。
- 当前连接、ST Connection Profile、镜渊独立 API 使用稳定 connection key 和统一请求入口。
- 同一连接默认 FIFO 单并发，不同连接允许并行，避免共享上游被多个任务同时压满。
- TaskQueue 增加任务级 AbortController；信号贯穿审核、修正、结构化修复、状态表、总结和连接适配器。
- 聊天切换、扩展禁用、内核停止和工作台取消都会主动中止旧任务及连接请求。
- Broker 统一请求超时；只对 rate_limit、network、upstream 做有界重试，支持 Retry-After、指数退避和抖动。
- 增加按连接熔断与半开恢复，避免持续故障造成请求风暴。
- 统一连接错误分类，并在诊断报告中加入活动请求、排队与熔断状态。
- 强化 stale-result gate：消息副作用前核对聊天作用域；延迟调度捕获原始作用域。
- 工作台任务队列为 queued/running 任务增加取消按钮。
- 新增 5 项 Connection Broker 故障注入测试；自动测试由 32 项增至 37 项。
- 将 `happy-dom` 从 17.6.3 升级到 20.10.6；当前 `npm audit` 为 0 个已知漏洞。
- 新增 `research/` 源码供应链记录、许可证矩阵、架构比较和 ADR。

## 1.1.0-alpha.9 — Foundation Kernel Phase 1

- 新增 Service Container、Capability Registry、Event Router、Chat Scope Manager 和 Lock Manager。
- 业务事件统一通过 Event Router，不再由管线和 UI 各自重复监听酒馆原始事件。
- 持久聊天键以 SillyTavern 真实聊天 ID 为权威；同角色不同聊天不再依赖角色名或临时 UUID 区分。
- 未保存聊天的数据只保存在内存，关闭或切换后不进入持久缓存。
- 兼容读取 alpha.8 旧聊天键，并在访问时迁移到新聊天键。
- 任务新增持久化记录与 scopeRevision；聊天切换后旧任务标记 stale，结果不得写入新聊天。
- 页面重载后将遗留的 queued/running 任务安全标记为 stale。
- 诊断面板新增 Foundation Kernel、聊天作用域和持久任务检查。
- 保留 alpha.8 的审核、修正、表格、总结、独立 API、世界书和图谱功能。
